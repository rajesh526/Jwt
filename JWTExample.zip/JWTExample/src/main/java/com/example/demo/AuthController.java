package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller

public class AuthController {
	  @Autowired
	    AuthenticationManager authenticationManager;

	    @Autowired
	    JwtTokenProvider jwtTokenProvider;

	    @Autowired
	    UserRepository users;
	 
	    @Autowired
	    private CustomUserDetailsService userService;
	    
	    
	    @RequestMapping("/")
	    public String home() {
	    	return "home";
	    }
	    
	    @RequestMapping("/index")
	    public String index() {
			return "index";
	    	
	    }
	    @RequestMapping("/About")
	    public String About() {
			return "About";
	    	
	    }
	    @RequestMapping("/Academic")
	    public String Academic() {
			return "Academic";
	    	
	    }
	    @RequestMapping("/Academics")
	    public String Academics() {
			return "Academics";
	    	
	    }
	    @RequestMapping("/Admission")
	    public String Admission() {
			return "Admission";
	    	
	    }
	    @RequestMapping("/Admissiondetails")
	    public String Admissiondetails() {
			return "Admissiondetails";
	    	
	    }
	    @RequestMapping("/Campus")
	    public String Campus() {
			return "Campus";
	    	
	    }
	    @RequestMapping("/Contact")
	    public String Contact() {
			return "Contact";
	    	
	    }
	    @RequestMapping("/directormsg")
	    public String DirectorMsg() {
			return "directormsg";
	    	
	    }
	    @RequestMapping("/enquiry")
	    public String Enquiry() {
			return "enquiry";
	    	
	    }
	    @RequestMapping("/Gallery")
	    public String Gallery() {
			return "Gallery";
	    	
	    }
	    @RequestMapping("/Info")
	    public String Info() {
			return "Info";
	    	
	    }
	    @RequestMapping("/Infrastructure")
	    public String Infratructure() {
			return "Infrastructure";
	    	
	    }
	    @RequestMapping("/Medical")
	    public String Medical() {
			return "Medical";
	    	
	    }
	    @RequestMapping("/MiddlePrimary")
	    public String MiddlePrimary() {
			return "MiddlePrimary";
	    	
	    }
	    @RequestMapping("/mission")
	    public String mission() {
			return "mission";
	    	
	    }
	    @RequestMapping("/primary")
	    public String Primary() {
			return "primary";
	    	
	    }
	    @RequestMapping("/prinicipalmsg")
	    public String PrincipalMsg() {
			return "prinicipalmsg";
	    	
	    }
	    @RequestMapping("/RegisterDetails")
	    public String RegisterDetails() {
			return "RegisterDetails";
	    	
	    }
	    @RequestMapping("/Secondary")
	    public String Secondary() {
			return "Secondary";
	    	
	    }
	    @RequestMapping("/Sports")
	    public String Sports() {
			return "Sports";
	    	
	    }
	    @RequestMapping("/Transport")
	    public String Transport() {
			return "Transport";
	    	
	    }
	    @RequestMapping("/view")
	    public String view() {
			return "view";
	    	
	    }
	    
	    @RequestMapping("/Sign")
	    public String login() {
			return "Sign";
	    	
	    }
	    @RequestMapping("/Register")
	    public String Register() {
			return "Register";
	    	
	    }

	    
	  
	    @RequestMapping(value="/Login", method=RequestMethod.POST,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	    public BodyBuilder login( Sign user) {
	        try {
	            String username = user.getUsername();
	            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, user.getPassword()));
	            String token = jwtTokenProvider.createToken(username, this.users.findByUsername(username).getRoles());
	            Map<Object, Object> model = new HashMap<>();
	           model.put("username", username);
	           model.put("token", token);
	          HttpHeaders headers = new HttpHeaders();
	           headers.add("Responded", "AuthController");
	            //return ResponseEntity.ok(model);

	           return ResponseEntity.accepted().headers(headers).allow(HttpMethod.GET);
	        } catch (AuthenticationException e) {
	            throw new BadCredentialsException("Invalid email/password supplied");
	        }
	    }
/*

		@RequestMapping(value="/save",method=RequestMethod.POST)
	    public String register(User user) {
	        User userExists = userService.findUserByUsername(user.getUsername());
	        if (userExists != null) {
	            throw new BadCredentialsException("User with username: " + user.getUsername() + " already exists");
	        }
	        userService.saveUser(user);
	        //Map<Object, Object> model = new HashMap<>();
	        //model.put("message", "User registered successfully");
			return "Sign";
	        
	    }
	    */
	     
	

	    @RequestMapping(value="/save",method = RequestMethod.POST )
	    public String register(@Valid User user) {
	        User userExists = userService.findUserByUsername(user.getEmail());
	        if (userExists != null) {
	            throw new BadCredentialsException("User with username: " + user.getEmail() + " already exists");
	        }
	        userService.saveUser(user);
	        //Map<Object, Object> model = new HashMap<>();
	        //model.put("message", "User registered successfully");
	        return "Sign" ;
	    }
	  /*
	  
	    @SuppressWarnings("static-access")
		@RequestMapping(value="/Login",method=RequestMethod.POST)
	    public ModelAndView Login(@Valid Sign user,HttpServletRequest Request,HttpServletResponse Response) {
	    	String username=user.getUsername();
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username,user.getPassword()));
			String token=jwtTokenProvider.createToken(username, this.users.findByUsername(username).getRoles());
			   //HttpHeaders headers = new HttpHeaders();
			   ModelAndView model=new ModelAndView();
			//Map<Object, Object> model = new HashMap<>();
			 //model.put("username", username);
			    //model.put("token", token);
			    System.out.println(token);
			   
			    //System.out.println(model);
			    //return new ResponseEntity<>(ok(model));
				  model.setViewName("/index");
				  return model;
			
	    	
	    }
	    /*

    /*
		private ModelAndView ok(Map<Object, Object> model) {
			 ModelAndView modelAndView = new ModelAndView();
			return modelAndView;
		}
		
		*/
	
	 /*
	    @RequestMapping(value = "/Login", method = RequestMethod.GET)
		public ModelAndView Signin() {
		    ModelAndView modelAndView = new ModelAndView();
		    //modelAndView.setViewName("");
		    return modelAndView;
		}
		*/
	   /*
	    @RequestMapping(value="/Login",method = RequestMethod.POST ,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	    public String login(@Valid Authbody data) {
	        try {
	            String username = data.getUsername();
	            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, data.getPassword()));
	            String token = jwtTokenProvider.createToken(username, this.users.findByUsername(username).getRoles());
	            Map<Object, Object> model = new HashMap<>();
	            model.put("username", username);
	            model.put("token", token);
	         return "index";
	          // return  new ResponseEntity<Sign>(HttpStatus.OK);
	        } catch (AuthenticationException e) {
	            throw new BadCredentialsException("Invalid email/password supplied");
	        }
			
	    }
	  */
	   /*
	    @RequestMapping(value="/Login",method = RequestMethod.POST ,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	    public ResponseEntity<Sign> login(@Valid Authbody data) {
	        try {
	            String username = data.getUsername();
	            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, data.getPassword()));
	            String token = jwtTokenProvider.createToken(username, this.users.findByUsername(username).getRoles());
	            Map<Object, Object> model = new HashMap<>();
	            model.put("username", username);
	            model.put("token", token);
	            //HttpHeaders responseHeaders = new HttpHeaders();
	           return  new ResponseEntity<Sign>(HttpStatus.OK);
	        } catch (AuthenticationException e) {
	            throw new BadCredentialsException("Invalid email/password supplied");
	        }
			
	    }
	    */
	    /*
	    
	    	    @RequestMapping(value="/Login")
	    public String login(@Valid Sign data) {
	        String username = data.getUsername();
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, data.getPassword()));
			String token = jwtTokenProvider.createToken(username, this.users.findByUsername(username).getRoles());
			Map<Object, Object> model = new HashMap<>();
			model.put("username", username);
			model.put("token", token);
			
			return "Index";
	    }
*/
	   
	   /*
	   
		@RequestMapping(value="/save")
	    public String Register(@Valid User user) {
	    	User userExists=userService.findUserByUsername(user.getUsername());
	    	 if (userExists != null) {
		            throw new BadCredentialsException("User with username: " + user.getEmail() + " already exists");
		        }
	    	    userService.saveUser(user);
		        Map<Object, Object> model = new HashMap<>();
		        model.put("message", "User registered successfully");
			return "Sign";
	    	
	    }
	   
	   
	    */
	 
	   
	}

