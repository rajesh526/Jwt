
function validateregister(){
var name =document.registerform.username.value;
var pwd=document.registerform.password.value;
var  cpwd=document.registerform.cpassword.value;
if (name==null || name=="")
{
alert("name can't be blank");
return false;
}
else if(pwd != cpwd)
{
alert("Password must be same");
return false;
}
else if(pwd.length<6)
{
alert("password must be atleast 6 characters long");
return false;
}
else{
	alert("Registered Successfully")
	}
}
